package de.diegrafen.exmatrikulatortd.view.screens;

import de.diegrafen.exmatrikulatortd.controller.MainController;

/**
 * @author Jan Romann <jan.romann@uni-bremen.de>
 * @version 15.06.2019 12:06
 */
public class IntroScreen extends BaseScreen {

    public IntroScreen (MainController mainController) {
        super(mainController);
    }

    @Override
    public void init () {
        //System.out.println("Dies ist der MenuScreen!");
        //getMainController().createNewSinglePlayerGame();
    }

    private void showIntro () {

    }
}
