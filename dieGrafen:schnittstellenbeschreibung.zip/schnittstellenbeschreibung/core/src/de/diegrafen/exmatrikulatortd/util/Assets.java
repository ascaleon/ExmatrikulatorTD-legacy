package de.diegrafen.exmatrikulatortd.util;

/**
 *
 * Dient der Speicherung der Informationen über Assets
 *
 * @author Jan Romann <jan.romann@uni-bremen.de>
 * @version 15.06.2019 00:58
 */
public class Assets {





}
