package de.diegrafen.exmatrikulatortd.communication.client.requests;

/**
 * @author Jan Romann <jan.romann@uni-bremen.de>
 * @version 14.06.2019 05:07
 */
public abstract class Request {

    java.util.Date timeSent;

}
