package de.diegrafen.exmatrikulatortd.communication.client.requests;

/**
 * @author Jan Romann <jan.romann@uni-bremen.de>
 * @version 15.06.2019 15:53
 */
public class GetServerStateRequest extends Request{

    public GetServerStateRequest() {

    }
}
