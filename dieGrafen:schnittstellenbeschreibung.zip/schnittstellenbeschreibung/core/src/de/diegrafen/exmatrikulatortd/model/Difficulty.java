package de.diegrafen.exmatrikulatortd.model;

public enum Difficulty {

    TESTMODE, EASY, MEDIUM, HARD;
}
